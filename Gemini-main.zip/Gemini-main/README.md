##How To setup
search on google
google ai studio 
get apikey
app.py me jao > 👉🏻👉🏻aapki apikey 👈🏻👈🏻
isme apni api key daalo
same .env me
same gemini.py me 
now deploy on render

start command is

python app.py
